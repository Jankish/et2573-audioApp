package com.softa.babywatch;

public enum BabyState {
	
	SLEEPING,
	NOISE,
	AWAKE

}
